package com.humancoffee.model;

import java.util.Comparator;

public class OrderBottom {
//	public String order_id;
	public String product_id;
	public int cnt;
	public int delete = 0;
}
