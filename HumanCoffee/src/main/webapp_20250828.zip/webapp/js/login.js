/**
 *  로그아웃 확인 서비스
 */
function Logout() {
	if(!confirm('정말 로그아웃 하시겠습니까?')) {
		return false;
	}
	location.href = '/HumanCoffee/loginService/logout.jsp';
}
/**
 *  회원가입 시 패스워드 동일 여부 확인 서비스
 */
function Logout() {
	if(!confirm('정말 로그아웃 하시겠습니까?')) {
		return false;
	}
	location.href = '/HumanCoffee/loginService/logout.jsp';
}